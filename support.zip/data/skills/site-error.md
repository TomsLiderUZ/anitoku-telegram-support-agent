---
slug: site-error
name: Sayt ochilmayapti yoki xato beradi
priority: 30
triggers: sayt ochilmayapti, site not loading, site error, не открывается сайт, site не работает, error
---

# Sayt ochilmayapti yoki xato beradi

Foydalanuvchi saytga kirishda texnik muammo borligini aniqlash va hal qilishni xohlaydi

## Ko'rsatma
Muammoni aniqlash uchun foydalanuvchidan qurilma, brauzer, xato xabari yoki skrinshot so'rang. Kerak bo'lsa vaqtinchalik yechim (keshni tozalash, VPN, boshqa brauzer) taklif qiling. Muammo davom etsa texnik jamoaga yuborilishini bildiring.

## Namunalar
Iltimos, qaysi qurilma va brauzerda sayt ochilmayapti, xato xabari qanday ko'rinadi? Skrynshot yuborsangiz, tezroq yordam bera olamiz.
