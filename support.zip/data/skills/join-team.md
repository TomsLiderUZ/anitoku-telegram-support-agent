---
slug: join-team
name: Jamoaga qabul
priority: 25
triggers: ishlamoqchi, ish, vakansiya, jamoa, ovoz, aktyor, dubbing, tarjimon, montaj, dayber, qo'shilmoqchi
---

# Jamoaga qabul

Ovoz aktyorligi, tarjima, montaj bo'yicha murojaatlar

## Ko'rsatma
Nomzodni iliq kutib ol. Ochiq yo'nalishlar: ovoz aktyor(ka)lari, montajyorlar, dayberlar, tarjimonlar. Qaysi yo'nalish qiziqtirishini so'ra va namuna ish (ovoz yozuvi yoki tarjima parchasi) so'ra. Yakuniy qaror uchun @anitoku_admin ga yo'naltir.

