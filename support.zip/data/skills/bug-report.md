---
slug: bug-report
name: Texnik muammo
priority: 15
triggers: ishlamayapti, ochilmayapti, xato, error, muammo, bug, sekin, yuklanmayapti, kirolmayapman
---

# Texnik muammo

Sayt/ilova ishlamayotgani haqidagi shikoyatlar

## Ko'rsatma
Muammo uchun uzr so'ra, keyin aniq diagnostika ma'lumotini so'ra: qurilma va brauzer, qanday xato xabari chiqmoqda, skrinshot. Ma'lumot to'liq bo'lsa — texnik jamoaga uzatilishini ayt va escalate_to_human vositasidan foydalan.

