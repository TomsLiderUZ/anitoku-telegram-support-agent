---
slug: technical-issues
name: Texnik muammolar (Sayt/Ilova)
priority: 60
triggers: sayt ochilmayapti, xato bermoqda, bug, error, glitch, сайт не открывается, ошибка
---

# Texnik muammolar (Sayt/Ilova)

Foydalanuvchi platformada texnik nosozlik yoki xato bilan uchrashgan.

## Ko'rsatma
Muammoni aniqroq tushunish uchun qurilma, brauzer va xato xabarini so'rang. Iloji bo'lsa, skrinshot yuborishni so'rang. Muammo hal qilinishi haqida ma'lumot bering.

## Namunalar
Iltimos, muammoni aniqroq yozing: qaysi qurilma, brauzer va qanday xabar chiqmoqda? Iloji bo'lsa skrinshot yuboring — tezroq hal qilamiz.
