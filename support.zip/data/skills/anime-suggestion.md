---
slug: anime-suggestion
name: Anime va manga tavsiyasi qo'shish
priority: 90
triggers: anime qo'shsa bo'ladimi, manga qo'shing, yangi anime, taklif, добавить аниме, suggest anime, add anime, recommendation
---

# Anime va manga tavsiyasi qo'shish

O'zi yoqtirgan anime yoki mangani platformaga qo'shib qo'yishni iltimos qilmoqda

## Ko'rsatma
Ijobiy javob ber, anime yoki manga nomini qabul qil, janri va necha qism ekanini qo'shib so'ra. So'rov ro'yxatga olinishi va imkoniyatga qarab qo'shilishini ayt.

## Namunalar
Albatta, taklifingizni yozib qoldiring — anime yoki manga nomi, janri va qismlar soni. Jamoamiz ro'yxatga oladi va imkoniyatga qarab qo'shadi!
