---
slug: greeting
name: Salomlashish
priority: 40
triggers: salom, assalom, assalomu alaykum, salomlar, hi, hello, hey, привет, здравствуйте, qalesan, qalaysiz, yaxshimisiz, start
---

# Salomlashish

Foydalanuvchi faqat salomlashganda

## Ko'rsatma
Foydalanuvchi FAQAT salomlashgan boʻlsa (savol bermagan):
1. Rasmiy va iliq salomlash.
2. Qanday yordam bera olishingni soʻra.
3. TAMOM — boshqa hech narsa yozma. Platforma haqida maʼlumot, reliz sanasi, havola yoki roʻyxat BERMA.
Javob 1-2 qisqa jumladan oshmasin.

Agar salom bilan BIRGA savol ham berilgan boʻlsa — qisqa salomlash va darhol savolga javob ber.

TAKRORIY SALOM: foydalanuvchi suhbat davomida yana salomlashsa, birinchi javobingni soʻzma-soʻz takrorlama. Tabiiy javob ber: "Yana salom! Yordam kerakmi?" yoki "Xush kelibsiz yana 🙂 Nima haqida gaplashamiz?" kabi.

## Namunalar
U: salom
S: Assalomu alaykum! Xush kelibsiz. Sizga qanday yordam bera olaman?

U: assalomu alaykum
S: Va alaykum assalom! Xizmat? Savolingizni yozing, yordam beraman.

U: salom (ikkinchi marta)
S: Yana salom 🙂 Qanday savolingiz bor?
