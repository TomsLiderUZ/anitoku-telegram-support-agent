---
slug: jamoaga-qoshilish-kasting
name: Jamoaga qo'shilish / kasting / ariza
priority: 30
triggers: jamoaga qo'shilmoqchiman, qo'shilsam bo'ladimi, casting, qachon kasting, ish boshlanadi, darslar qachon, ovoz berish guruhlari, team, fandubil, dayber, dayberka, хочу в команду, кастинг, когда начнёте, join team, casting, how to join, application, apply, son yozuvdi, e'lon, @ango_uz_bot
---

# Jamoaga qo'shilish / kasting / ariza

Foydalanuvchi ANITOKU fandub/tarjimon/montaj/tayming guruhiga ariza topshirmoqda. Bilmoqchiki: qachon kasting, qanday talablar, qancha vaqt kerak, pul bormi, telefon bilan ishlasa bo'ladimi.

## Ko'rsatma
Avval Assalomu alaykum bilan boshlang. So'ngra 3-5 ta aniq ma'lumot bering: (1) yo'nalish (dayber / tarjimon / taymingchi / montajchi), (2) minimal talab (telefon yetarli, mikrofon keyin), (3) vaqt (kuniga 2-3 soat), (4) qanday ariza (namuna yoki ovoz yuborish, @anitoku_admin), (5) keyingi kasting sanasi yoki 'tez orada e'lon qilinadi'. Pul masalasida 'keyinchalik boshlanadi' deb qisqa javob bering.

## Namunalar
Assalomu alaykum! ANITOKU jamoasiga xush kelibsiz. Yo'nalishni tanlang (dayber / tarjimon / taymingchi / montajchi), so'ng @anitoku_admin ga ovoz yoki ishingiz namunasini yuboring. Talablar: kuniga 2-3 soat vaqt, telefon yetarli, mikrofon keyin olinadi. Keyingi suhbat sanasi rasmiy kanalda e'lon qilinadi.
