---
slug: mobile-app
name: Mobil ilova
priority: 60
triggers: mobil ilova, mobile app, приложение, app, android, ios, app mavjudmi, app download, mobile version, мобильное приложение
---

# Mobil ilova

ANITOKU mobil ilovasi mavjudligi va rejalari haqida ma'lumot olish

## Ko'rsatma
Ilova rejalashtirilganligini, kross‑platforma loyiha ekanligini, rasmiy kanalda e'lon qilinishini ayting.

## Namunalar
Ha, ANITOKU kross‑platforma loyiha — veb‑sayt va mobil ilova rejalashtirilgan. Ilova haqida ma’lumot rasmiy kanalda e’lon qilinadi.
