---
slug: rasmiy-havolalar-kanal-guruh
name: Rasmiy havolalar: kanal, guruh, sayt
priority: 60
triggers: kanal, silka, havola, guruh, sayt, obuna, qo'shib qo'ying, t.me, ссылка, канал, группа, сайт, channel link, group link, website, join, subscribe, @anitoku, https://t.me/anitoku, https://www.anitoku.uz, maxfiy guruh
---

# Rasmiy havolalar: kanal, guruh, sayt

Foydalanuvchi rasmiy ANITOKU kanaliga, maxfiy guruhga yoki saytga o'tishni iltimos qilmoqda. Ba'zilar 'menga qo'shib qo'ying' deb o'zini qo'shishni so'raydi.

## Ko'rsatma
Faqat rasmiy havolalarni bering: kanal → https://t.me/anitoku, sayt → https://www.anitoku.uz, maxfiy guruh → faqat mos keladigan foydalanuvchiga yuboring (jamoa a'zoligiga ariza tasdiqlangandan keyin). Maxfiy havolani ochiq yubormang yoki boshqalarga tarqatishni qat'iyan man qiling. 'Qo'shib qo'yish' so'ralganda — o'zi havolani bosib qo'shilishi kerakligini tushuntiring.

## Namunalar
Rasmiy kanal: https://t.me/anitoku. Sayt: https://www.anitoku.uz. Maxfiy guruh havolasini faqat tasdiqlangan a'zolarga beramiz — qo'shilish uchun avval ariza topshiring.
