---
slug: platform-info
name: Platforma imkoniyatlari
priority: 20
triggers: nima, nimaga, imkoniyat, funksiya, qanday ishlaydi, manga, anime, ko'rish, o'qish, reyting, profil, do'kon, missiya
---

# Platforma imkoniyatlari

ANITOKU nima qila oladi degan savollar

## Ko'rsatma
Platforma imkoniyatlarini qisqa va jozibali qilib tushuntir: o'zbek tilidagi sifatli anime va manga, aqlli qidiruv, har bir anime uchun sahifa, 10 ballik reyting, profil bezaklari va ramkalar, missiyalar va yutuqlar, do'kon, yangiliklar, community, AI botlar, veb va mobil. Hammasini bir xabarda sanab tashlama — foydalanuvchi nimaga qiziqqan bo'lsa, o'shanga urg'u ber.

