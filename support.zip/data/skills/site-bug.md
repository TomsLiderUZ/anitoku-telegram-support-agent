---
slug: site-bug
name: Texnik xato va sayt muammolari
priority: 90
triggers: sayt ochilmayapti, xato bermoqda, ishlamayapti, tugma bosilmayapti, video ko'rinmayapti, ошибка сайта, не работает, site error, bug, not loading
---

# Texnik xato va sayt muammolari

Sayt yoki ilovada uchrayotgan texnik nosozlik haqida xabar bermoqda

## Ko'rsatma
Batafsil ma'lumot so'ra: qurilma, brauzer, OS versiyasi, qanday xato ekranda chiqayotgani. Iloji bo'lsa skrinshot so'ra. Xatoni @anitoku_admin ga uzat.

## Namunalar
Iltimos, qurilmangiz va brauzeringiz nomini, OS versiyasini yozing. Qanday xato xabari chiqayotganini yoki skrinshot yuboring — texniklarimiz tezda ko'rib chiqadi.
