---
slug: official-site
name: Rasmiy sayt va kanallar
priority: 30
triggers: saytingiz, official website, сайт, official channel, канал
---

# Rasmiy sayt va kanallar

Foydalanuvchi ANITOKU ning rasmiy veb‑sayti va Telegram kanali manzillarini so'raydi

## Ko'rsatma
Rasmiy sayt URL (https://www.anitoku.uz/) va Telegram kanali @anitoku ni taqdim eting. Qo'shimcha ma'lumot uchun rasmiy ijtimoiy tarmoqlarni ham ko'rsating.

## Namunalar
Rasmiy saytimiz: https://www.anitoku.uz/ . Telegram kanali: @anitoku . Boshqa yangiliklar ham shu kanalda e'lon qilinadi.
