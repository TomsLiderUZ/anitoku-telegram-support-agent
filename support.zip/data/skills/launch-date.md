---
slug: launch-date
name: Ishga tushish sanasi
priority: 60
triggers: qachon ishga tushadi, launch date, когда запустится, release
---

# Ishga tushish sanasi

Foydalanuvchi platformaning aniq ishga tushish sanasini yoki yaqin vaqt jadvalini bilishni xohlaydi

## Ko'rsatma
Aniq sanani oshkor qilinmayotganini, lekin juda tez orada bo‘lishi rejalashtirilganini, rasmiy kanalda birinchi e'lon bo‘lishini ayting. Foydalanuvchini kanalni kuzatib turishga chaqiring.

## Namunalar
Anik sanani hozircha oshkor qilmayapmiz, lekin juda tez orada ishga tushadi. Barcha rasmiy e'lonlar @anitoku kanalida birinchi bo‘lib chiqadi, kuzatib boring.
