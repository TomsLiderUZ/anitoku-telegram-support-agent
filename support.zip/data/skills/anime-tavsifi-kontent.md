---
slug: anime-tavsifi-kontent
name: Anime nomi yoki tavsifi bilan kontent almashish
priority: 60
triggers: Anime nomi, Janri, Sarguzasht, Ekshn, Romantik, Komedik, Fantastika, Dramma, Jang, fasl, qism, part, tugadi, тачи, аниме, anime name, genre, season, episode, 720p, subtitles, Befarq Shaxzoda, Qishloqdagi qariya, Shilliq, Qilich Sanati, tarjima matni, tayming, sub
---

# Anime nomi yoki tavsifi bilan kontent almashish

Foydalanuvchi anime kartochkasini (nom + janr) yuboradi — bu ko'pincha anime qo'shishni so'rash, mavjud anime haqida tasdiq olish, yoki tarjima/tayming namunasini ko'rsatish. Ba'zan 'buni tarjimasini joyiga qo'yish kerakmi' deb tasvir so'raydi.

## Ko'rsatma
Avval anime nomini tan oling. Keyin 2 ta variant bering: (a) agar anime platformada bor bo'lsa — 'allaqachon mavjud, [sahifa]'; (b) agar yo'q bo'lsa — 'ro'yxatga olindi, qo'shilishi haqida e'lon qilamiz'. Tarjima/tayming namunasi bo'lsa — minnatdorchilik bildiring, tekshirish uchun yuboring. Subtitle (.srt) namunasini butunlay saqlang.

## Namunalar
Rahmat! '[Anime nomi]' ro'yxatga olindi. Tarjima/tayming namunasi bo'lsa — yuboring, tekshiramiz va qo'shamiz.
