---
slug: team-joining
name: Jamoaga qo'shilish (Dublyaj/Montaj/Tarjima)
priority: 30
triggers: jamoaga qo'shilmoqchiman, dayberlikka olasizmi, kasting qachon, ovoz berish guruhiga, montajchi kerakmi, tarjimon kerakmi, join team, apply for dubbing, кастинг, присоединиться к команде
---

# Jamoaga qo'shilish (Dublyaj/Montaj/Tarjima)

Foydalanuvchi ANITOKU jamoasining bir qismiga (ovoz aktyori, montajchi, tarjimon) a'zo bo'lishni istaydi va jarayonni so'raydi.

## Ko'rsatma
Foydalanuvchidan ism, yosh va qaysi yo'nalishda qiziqishini (ovoz, montaj, tarjima) so'rang. Agar namuna ishi bo'lsa, uni yuborishni taklif qiling. Rasmiy javob sifatida @anitoku_admin ga yozishni yoki maxsus guruhga qo'shilishni ko'rsating. Tajribasi bo'lmasa ham, qiziqishini baholang va o'rgatish imkoniyati haqida ma'lumot bering.

## Namunalar
Assalomu alaykum! Jamoamizga qo'shilish uchun qaysi yo'nalishda qiziqishingizni (ovoz, montaj, tarjima) yozing. Agar oldindan tayyorlangan namuna ishingiz bo'lsa, uni yuboring. Keyinchalik @anitoku_admin orqali bog'lanamiz.
