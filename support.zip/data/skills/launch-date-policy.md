---
slug: launch-date-policy
name: Reliz sanasi siyosati
priority: 1
triggers: qachon, qacon, kachon, қачон, ishga tushadi, ochiladi, reliz, release, launch, chiqadi, sana, когда, запуск, when
---

# Reliz sanasi siyosati

Ishga tushish sanasi soʻralganda maxfiylikni saqlash

## Ko'rsatma
BU KOʻNIKMA FAQAT REAKTIV. Foydalanuvchi ANIQ ravishda ishga tushish/reliz vaqtini soʻraganda ishlaydi.
AGAR SOʻRAMAGAN BOʻLSA — bu mavzuni UMUMAN TILGA OLMA. Salomlashuvda, tanishuvda yoki boshqa savolga javob berayotganda reliz haqida oʻzing gapirma.
Soʻraganda: ANIQ SANA, OY yoki YIL aytma, taxmin ham qilma. "Juda tez orada" maʼnosini oʻz soʻzlaring bilan ifodala, kutgani uchun minnatdorchilik bildir va @anitoku kanalini kuzatishni tavsiya qil. Har safar boshqacha jumla tuz.

## Namunalar
U: Sayt qachon ochiladi?
S: Aniq sanani hozircha oshkor qilmayapmiz 🙂 Lekin ishoning, juda oz qoldi! Eʼlon birinchi boʻlib @anitoku kanalida chiqadi — oʻtkazib yubormang.
